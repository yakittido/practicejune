import random
import telebot
from telebot import types

file = open('./mytoken.txt')
mytoken = file.read()

bot = telebot.TeleBot(mytoken)

answers = ['?','??','???']

@bot.message_handler(commands=['start'])
def welcome(message):

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('Favorite cfg')
    button2 = types.KeyboardButton('Streamer cfg')
    button3 = types.KeyboardButton('skywhywalker cfg')

    markup.row(button1)
    markup.row(button2)
    markup.row(button3)

    if message.text == '/start':
        bot.send_message(message.chat.id, f'привет, {message.from_user.first_name}!\nэто бот с моими любымими конфигами игроков в cs:go\n ', reply_markup=markup)
    else:
        bot.send_message(message.chat.id, 'я отходил ты затащил или че', reply_markup=markup)



@bot.message_handler()
def info(message):
    if message.text == 'Favorite cfg':
        favoriteChapter(message)
    elif message.text == 'Streamer cfg':
        streamersChapter(message)
    elif message.text == 'skywhywalker cfg':
        skyChapter(message)
    elif message.text == 'deko cfg':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        photo = open("C:\\Users\\yakit\\Desktop\\сfg\\deko.jpg", 'rb')
        bot.send_photo(message.chat.id, photo)
        bot.send_document(message.chat.id, open("C:\\Users\\yakit\\Desktop\\сfg\\deko.cfg"))
    elif message.text == 'Z1mple cfg':
        photo = open("C:\\Users\\yakit\\Desktop\\сfg\\Z1mple.jpg", 'rb')
        bot.send_photo(message.chat.id, photo)
        bot.send_document(message.chat.id, open("C:\\Users\\yakit\\Desktop\\сfg\\Z1mple.cfg"))
    elif message.text == 'm0nesy cfg':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        photo = open("C:\\Users\\yakit\\Desktop\\сfg\\m0nesy.jpg", 'rb')
        bot.send_photo(message.chat.id, photo)
        bot.send_document(message.chat.id, open("C:\\Users\\yakit\\Desktop\\сfg\\m0nesy.cfg"))
    elif message.text == 'Boombl4 cfg':
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        photo = open("C:\\Users\\yakit\\Desktop\\сfg\\boombl4.jpg", 'rb')
        bot.send_photo(message.chat.id, photo)
        bot.send_document(message.chat.id, open("C:\\Users\\yakit\\Desktop\\сfg\\boombl4.cfg"))





    elif message.text == 'Buster':
        photo = open("C:\\Users\\yakit\\Desktop\\сfg\\бустеренко.jpg", 'rb')
        bot.send_photo(message.chat.id, photo)
        bot.send_document(message.chat.id, open("C:\\Users\\yakit\\Desktop\\сfg\\бустеренко.cfg"))

    elif message.text == 'Evelone':
        bot.send_document(message.chat.id, open("C:\\Users\\yakit\\Desktop\\сfg\\evelone.cfg"))

    elif message.text == '↩️ Назад':
        favoriteChapter(message)
    elif message.text == 'ретейк на а':
        welcome(message)
    else:
        bot.send_message(message.chat.id, answers[random.randint(0, 3)])

def favoriteChapter(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('deko cfg')
    button2 = types.KeyboardButton('Z1mple cfg')
    button3 = types.KeyboardButton('m0nesy cfg')
    button4 = types.KeyboardButton('Boombl4 cfg')
    button5 = types.KeyboardButton('ретейк на а')
    markup.row(button1, button2)
    markup.row(button3, button4)
    markup.row(button5)

    bot.send_message(message.chat.id, 'продам гараж', reply_markup=markup)


def streamersChapter(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('Buster')
    button2 = types.KeyboardButton('Evelone')
    button3 = types.KeyboardButton('ретейк на а')
    markup.row(button1, button2)
    markup.row(button3)
    bot.send_message(message.chat.id, 'палковне бустр биг болс:', reply_markup=markup)


def skyChapter(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    button1 = types.KeyboardButton('ретейк на а')
    markup.row(button1)
    photo = open("C:\\Users\\yakit\\Desktop\\сfg\\узник.jpg", 'rb')
    bot.send_photo(message.chat.id, photo)
    bot.send_document(message.chat.id, open("C:\\Users\\yakit\\Desktop\\сfg\\skywhywalker.cfg"))


bot.polling(none_stop=True)