var cells = ['', '', '', '', '', '', '', '', ''];


var currentPlayer = 'X';


function updateBoard() {
 for (var i = 0; i < cells.length; i++) {
  document.getElementById(i+1).textContent = cells[i];
 }
}


function checkGameOver() {

 for (var i = 0; i < cells.length; i += 3) {
  if (cells[i] && cells[i] === cells[i+1] && cells[i] === cells[i+2]) {
   return true;
  }
 }

 for (var i = 0; i < 3; i++) {
  if (cells[i] && cells[i] === cells[i+3] && cells[i] === cells[i+6]) {
   return true;
  }
 }

 if (cells[0] && cells[0] === cells[4] && cells[0] === cells[8]) {
  return true;
 }
 if (cells[2] && cells[2] === cells[4] && cells[2] === cells[6]) {
  return true;
 }

 if (cells.every(function(cell) { return cell !== ''; })) {
  return true;
 }
 
 return false;
}


function cellClick(id) {

 if (cells[id-1] !== '' || checkGameOver()) {
  return;
 }

 cells[id-1] = currentPlayer;

 updateBoard();

 if (checkGameOver()) {
  alert('Игра окончена');
 } else {
  
  currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  
  document.getElementById('message').textContent = 'Current player: ' + currentPlayer;
 }
}


for (var i = 1; i <= 9; i++) {
 document.getElementById(i).addEventListener('click', function() {
  cellClick(this.id);
 });
}


document.getElementById('message').textContent = 'Current player: ' + currentPlayer;
